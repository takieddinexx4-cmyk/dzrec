package dz.rec

/** جودات جاهزة مدروسة: (الدقة، الإطارات، معدل البت) */
object Presets {
    val names = listOf("اقتصادي", "متوازن", "عالية", "أقصى")

    /** الضلع الأقصر بالبكسل: 0 = أصلية */
    val side = intArrayOf(720, 1080, 1080, 0)
    val fps = intArrayOf(30, 30, 60, 60)

    /** للتسجيل (Mbps) */
    val recMbps = intArrayOf(6, 12, 20, 32)

    /** للبث عبر WiFi (Mbps) */
    val castMbps = intArrayOf(5, 10, 16, 24)

    val castInfo = listOf(
        "720p · 30 إطار — الأكثر استقراراً على أي شبكة",
        "1080p · 30 إطار — الأنسب لمعظم الحالات",
        "1080p · 60 إطار — سلس للألعاب (يفضّل WiFi 5GHz)",
        "دقة الشاشة · 60 إطار — أعلى جودة (شبكة قوية فقط)"
    )
}
