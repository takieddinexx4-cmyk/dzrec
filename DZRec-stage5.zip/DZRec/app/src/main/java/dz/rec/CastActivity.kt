package dz.rec

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.res.ColorStateList
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class CastActivity : Activity() {

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var statusTv: TextView
    private lateinit var urlTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var startBtn: TextView
    private lateinit var copyBtn: TextView

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cast)
        prefs = Prefs(this)

        statusTv = findViewById(R.id.castStatus)
        urlTv = findViewById(R.id.castUrl)
        infoTv = findViewById(R.id.presetInfo)
        startBtn = findViewById(R.id.startBtn)
        copyBtn = findViewById(R.id.copyBtn)
        startBtn.isSelected = true
        findViewById<TextView>(R.id.backBtn).setOnClickListener { finish() }
        findViewById<View>(R.id.tvBtn).setOnClickListener { openTv() }

        val pi = prefs.castPreset.coerceIn(0, Presets.names.size - 1)
        infoTv.text = Presets.castInfo[pi]
        buildChips(this, R.id.rowPreset, Presets.names, pi) {
            prefs.castPreset = it
            infoTv.text = Presets.castInfo[it]
            applyLive()
        }
        buildChips(this, R.id.rowAudio, listOf("بدون", "صوت النظام", "ميكروفون", "الاثنان"),
            prefs.castAudio.coerceIn(0, 3)) { prefs.castAudio = it }
        buildChips(this, R.id.rowOri, listOf("تلقائي", "عمودي", "أفقي"),
            prefs.castOrient.coerceIn(0, 2)) {
            prefs.castOrient = it
            applyLive()
        }

        startBtn.setOnClickListener { onStartClick() }
        copyBtn.setOnClickListener {
            val u = CastState.url
            if (u == null) {
                Toast.makeText(this, "ابدأ البث أولاً", Toast.LENGTH_SHORT).show()
            } else {
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("url", u))
                Toast.makeText(this, "تم نسخ الرابط", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** تغيير الجودة أو الاتجاه يُطبَّق فوراً على البث الجاري */
    private fun applyLive() {
        if (CastState.running) {
            startService(Intent(this, CastService::class.java).setAction(CastService.ACTION_RECONFIG))
            Toast.makeText(this, "تم تطبيق الإعداد على البث", Toast.LENGTH_SHORT).show()
        }
    }

    /** الاتصال المباشر بالتلفاز عبر واجهة النظام (Cast / Smart View / Miracast) */
    private fun openTv() {
        val tries = listOf(
            Intent(Settings.ACTION_CAST_SETTINGS),
            Intent("android.settings.WIFI_DISPLAY_SETTINGS"),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        for (i in tries) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // نجرّب التالي
            }
        }
        Toast.makeText(
            this, "افتح لوحة الإعدادات السريعة واضغط Smart View أو Cast أو بث الشاشة",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun refresh() {
        CastState.error?.let {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            CastState.error = null
        }
        if (CastState.running) {
            statusTv.text = "البث يعمل · المتصلون: ${CastState.clients.get()}"
            urlTv.text = CastState.url ?: ""
            startBtn.text = "إيقاف البث"
        } else {
            statusTv.text = "البث متوقف"
            urlTv.text = "سيظهر الرابط هنا"
            startBtn.text = "بدء البث"
        }
    }

    private fun onStartClick() {
        if (CastState.running) {
            startService(Intent(this, CastService::class.java).setAction(CastService.ACTION_STOP))
            return
        }
        if (CastState.localIp() == null) {
            Toast.makeText(this, "اتصل بشبكة WiFi أو شغّل الهوتسبوت أولاً", Toast.LENGTH_LONG).show()
            return
        }
        val need = mutableListOf<String>()
        if (prefs.castAudio > 0 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 11) else askCapture()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11) askCapture()
    }

    @Suppress("DEPRECATION")
    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 21)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 21) {
            if (resultCode == RESULT_OK && data != null) {
                startForegroundService(
                    Intent(this, CastService::class.java)
                        .setAction(CastService.ACTION_START)
                        .putExtra(CastService.EXTRA_CODE, resultCode)
                        .putExtra(CastService.EXTRA_DATA, data)
                )
            } else {
                Toast.makeText(this, "تم إلغاء البث", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

fun buildChips(a: Activity, rowId: Int, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    val row = a.findViewById<LinearLayout>(rowId)
    val d = a.resources.displayMetrics.density
    fun dp(v: Int) = (v * d).toInt()
    val colors = ColorStateList(
        arrayOf(intArrayOf(android.R.attr.state_selected), intArrayOf()),
        intArrayOf(0xFF03120E.toInt(), 0xFFFFFFFF.toInt())
    )
    row.removeAllViews()
    labels.forEachIndexed { i, label ->
        val t = TextView(a)
        t.text = label
        t.setTextColor(colors)
        t.textSize = 14f
        t.setPadding(dp(16), dp(10), dp(16), dp(10))
        t.setBackgroundResource(R.drawable.bg_chip)
        t.isSelected = i == selected
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.marginEnd = dp(8)
        t.layoutParams = lp
        t.setOnClickListener {
            for (k in 0 until row.childCount) row.getChildAt(k).isSelected = k == i
            onPick(i)
        }
        row.addView(t)
    }
}
