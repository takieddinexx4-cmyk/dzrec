package dz.rec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

class RecorderService : Service() {

    companion object {
        const val ACTION_START = "dz.rec.START"
        const val ACTION_STOP = "dz.rec.STOP"
        const val ACTION_PAUSE = "dz.rec.PAUSE"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "rec"
        private const val NOTIF_ID = 77
    }

    private var projection: MediaProjection? = null
    private var capturer: ScreenCapturer? = null
    private var uri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> finish(true, null)
            ACTION_PAUSE -> togglePause()
        }
        return START_NOT_STICKY
    }

    private fun safe(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            // تجاهل
        }
    }

    @Suppress("DEPRECATION")
    private fun start(intent: Intent) {
        if (RecState.recording) return
        stopping = false
        val prefs = Prefs(this)
        createChannel()

        val hasMicPerm =
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val mode = if (hasMicPerm) prefs.audioMode else 0
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (mode > 0) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        try {
            startForeground(NOTIF_ID, buildNotification(), type)
        } catch (e: Exception) {
            finish(false, "تعذّر تشغيل خدمة التسجيل")
            return
        }

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) {
            finish(false, "لم يتم منح إذن تسجيل الشاشة")
            return
        }

        try {
            val cv0 = ScreenCapturer.canvasFor(this, prefs.shortSide, prefs.orient)
            val cw = cv0[0]
            val ch = cv0[1]
            val fps = prefs.fps
            val bitrate: Int = if (prefs.bitrate > 0) prefs.bitrate * 1_000_000
            else (cw.toLong() * ch * fps / 9).coerceIn(2_000_000L, 100_000_000L).toInt()

            val name = "DZRec_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/DZRec")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
            pfd = contentResolver.openFileDescriptor(uri!!, "rw")

            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    finish(true, null)
                }
            }, Handler(Looper.getMainLooper()))

            val cap = ScreenCapturer(
                this, p, Mp4Sink(pfd!!.fileDescriptor), cw, ch, prefs.shortSide, fps, bitrate,
                prefs.format == 1, mode, false
            ) { msg -> Handler(Looper.getMainLooper()).post { finish(false, msg) } }
            capturer = cap
            cap.start()

            RecState.paused = false
            RecState.accumMs = 0L
            RecState.activeSince = SystemClock.elapsedRealtime()
            RecState.recording = true
            if (prefs.shake) registerShake()
        } catch (e: Exception) {
            finish(false, "تعذّر بدء التسجيل بهذه الإعدادات، جرّب H.264 أو دقة أقل أو بدون صوت النظام")
        }
    }

    private fun finish(valid: Boolean, error: String?) {
        if (stopping) return
        stopping = true
        var ok = valid
        var err = error

        val cap = capturer
        capturer = null
        if (cap != null) {
            val r = try {
                cap.stop()
            } catch (e: Exception) {
                false
            }
            if (!r && ok) {
                err = "التسجيل قصير جداً أو لم يبدأ"
                ok = false
            }
        }
        val p = projection
        projection = null
        safe { p?.stop() }
        safe { pfd?.close() }
        pfd = null

        val u = uri
        uri = null
        if (u != null) {
            if (ok) {
                safe {
                    val cv = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(u, cv, null, null)
                    RecState.lastUri = u
                    Prefs(this).lastUri = u.toString()
                }
            } else {
                safe { contentResolver.delete(u, null, null) }
            }
        }
        safe { sm?.unregisterListener(shakeL) }
        sm = null
        RecState.recording = false
        RecState.paused = false
        if (err != null) RecState.error = err
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun pauseAction(): Notification.Action {
        val pi = PendingIntent.getService(
            this, 5,
            Intent(this, RecorderService::class.java).setAction(ACTION_PAUSE),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_rec),
            if (RecState.paused) "استئناف" else "إيقاف مؤقت", pi
        ).build()
    }

    private fun togglePause() {
        val c = capturer ?: return
        if (!RecState.recording) return
        if (RecState.paused) {
            c.resume()
            RecState.activeSince = SystemClock.elapsedRealtime()
            RecState.paused = false
        } else {
            c.pause()
            RecState.accumMs += SystemClock.elapsedRealtime() - RecState.activeSince
            RecState.paused = true
        }
        safe { getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification()) }
    }

    private var sm: SensorManager? = null
    private val shakeL = object : SensorEventListener {
        var count = 0
        var first = 0L
        var lastSpike = 0L
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        override fun onSensorChanged(e: SensorEvent) {
            val x = e.values[0]
            val y = e.values[1]
            val z = e.values[2]
            val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
            if (g > 2.6f) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastSpike < 200) return
                lastSpike = now
                if (now - first > 1500) {
                    first = now
                    count = 0
                }
                count++
                if (count >= 3) {
                    count = 0
                    finish(true, null)
                }
            }
        }
    }

    private fun registerShake() {
        val m = getSystemService(SensorManager::class.java)
        val s = m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        m.registerListener(shakeL, s, SensorManager.SENSOR_DELAY_UI)
        sm = m
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "التسجيل", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stop), "إيقاف", stopPi
        ).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("DZ Rec")
            .setContentText(if (RecState.paused) "التسجيل متوقف مؤقتاً" else "جارٍ تسجيل الشاشة…")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(pauseAction())
            .addAction(stopAction)
            .build()
    }

    override fun onDestroy() {
        if (!stopping) finish(true, null)
        super.onDestroy()
    }
}
