package dz.rec

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import android.view.WindowManager
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * محرك الالتقاط: الشاشة ← OpenGL (تدوير + لوحة ثابتة) ← ترميز H.264/HEVC + صوت AAC ← Sink.
 * streaming=true: ترميز منخفض التأخير + تكرار الإطارات لمعدل ثابت.
 */
class ScreenCapturer(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val sink: Sink,
    canvasW: Int,
    canvasH: Int,
    shortSide: Int,
    fps: Int,
    bitrate: Int,
    private val hevc: Boolean,
    private val audioMode: Int, // 0 بدون، 1 النظام، 2 ميكروفون، 3 الاثنان
    private val streaming: Boolean,
    private val onError: (String) -> Unit
) {
    companion object {
        const val RATE = 44100
        private const val FRAMES = 1024
        private const val EGL_RECORDABLE = 0x3142

        private const val VS = "attribute vec4 aPos;\nattribute vec2 aTex;\nuniform mat4 uTex;\n" +
            "varying vec2 vTex;\nvoid main(){\n gl_Position=aPos;\n vTex=(uTex*vec4(aTex,0.0,1.0)).xy;\n}"
        private const val FS = "#extension GL_OES_EGL_image_external : require\n" +
            "precision mediump float;\nvarying vec2 vTex;\nuniform samplerExternalOES sTex;\n" +
            "void main(){\n gl_FragColor=texture2D(sTex,vTex);\n}"

        /** [عرض، ارتفاع، dpi] للشاشة الحالية بعد التصغير (أرقام زوجية) */
        @Suppress("DEPRECATION")
        fun sourceSize(ctx: Context, shortSide: Int): IntArray {
            val dm = DisplayMetrics()
            ctx.getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(dm)
            var w = dm.widthPixels
            var h = dm.heightPixels
            val short = minOf(w, h)
            if (shortSide in 1 until short) {
                val r = shortSide.toFloat() / short
                w = (w * r).toInt()
                h = (h * r).toInt()
            }
            return intArrayOf(w and 1.inv(), h and 1.inv(), dm.densityDpi)
        }

        /** حجم لوحة الفيديو حسب الاتجاه: 0 تلقائي، 1 عمودي، 2 أفقي (مضاعفات 16) */
        fun canvasFor(ctx: Context, shortSide: Int, orient: Int): IntArray {
            val s = sourceSize(ctx, shortSide)
            val sh = minOf(s[0], s[1])
            val lg = maxOf(s[0], s[1])
            val land = when (orient) {
                1 -> false
                2 -> true
                else -> s[0] > s[1]
            }
            var w = (if (land) lg else sh) / 16 * 16
            var h = (if (land) sh else lg) / 16 * 16
            if (w < 16) w = 16
            if (h < 16) h = 16
            return intArrayOf(w, h)
        }
    }

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var venc: MediaCodec? = null
    private var aenc: MediaCodec? = null
    private val vinfo = MediaCodec.BufferInfo()
    private val ainfo = MediaCodec.BufferInfo()

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglCtx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var eglCfg: EGLConfig? = null
    private var inputSurface: Surface? = null
    private var st: SurfaceTexture? = null
    private var srcSurface: Surface? = null
    private var vd: VirtualDisplay? = null
    private var dl: DisplayManager.DisplayListener? = null
    private var texId = 0
    private var prog = 0
    private var aPos = 0
    private var aTex = 0
    private var uTex = 0
    private val mtx = FloatArray(16)
    private val vbuf = fb(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val tbuf = fb(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))

    @Volatile private var cw = canvasW
    @Volatile private var ch = canvasH
    @Volatile private var side = shortSide
    @Volatile private var fps = fps
    @Volatile private var bitrate = bitrate
    @Volatile private var srcW = 0
    @Volatile private var srcH = 0
    private var dpi = 0

    private var startNs = 0L
    @Volatile private var pausedNs = 0L
    private var pauseStartNs = 0L
    @Volatile private var paused = false
    @Volatile private var running = false
    @Volatile private var failed = false
    @Volatile private var gotFrame = false
    private var haveFrame = false
    private var lastDrawNs = 0L

    private var recInt: AudioRecord? = null
    private var recMic: AudioRecord? = null
    private var audioThread: Thread? = null
    @Volatile private var audioRun = false
    private var needAudio = false

    private fun fb(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(a)
            position(0)
        }

    private fun safe(block: () -> Unit) {
        try {
            block()
        } catch (e: Throwable) {
            // تجاهل
        }
    }

    // ------------------------------------------------------------ البدء
    fun start() {
        val src = sourceSize(ctx, side)
        srcW = src[0]
        srcH = src[1]
        dpi = src[2]

        createVideoEncoder()
        if (audioMode > 0) setupAudio()
        sink.setAudio(needAudio)

        startNs = System.nanoTime()
        val t = HandlerThread("dzcap")
        t.start()
        thread = t
        val h = Handler(t.looper)
        handler = h
        val latch = CountDownLatch(1)
        var err: Throwable? = null
        h.post {
            try {
                running = true
                initGl()
                createSource(h)
                if (streaming) h.postDelayed(repeatRun, 1000L / fps)
            } catch (e: Throwable) {
                err = e
            } finally {
                latch.countDown()
            }
        }
        if (!latch.await(6, TimeUnit.SECONDS)) throw IllegalStateException("timeout")
        err?.let { throw it }
        if (needAudio) startAudioThread()
    }

    private fun createVideoEncoder() {
        val mime = if (hevc) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
        fun format(lowLatency: Boolean): MediaFormat {
            val f = MediaFormat.createVideoFormat(mime, cw, ch)
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            if (lowLatency) {
                f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
                if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LATENCY, 1)
                f.setInteger(MediaFormat.KEY_PRIORITY, 0)
            }
            return f
        }
        var enc = MediaCodec.createEncoderByType(mime)
        try {
            enc.configure(format(streaming), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            safe { enc.release() }
            enc = MediaCodec.createEncoderByType(mime)
            enc.configure(format(false), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        }
        venc = enc
        inputSurface = enc.createInputSurface()
        enc.start()
    }

    private fun createSource(h: Handler) {
        val s = SurfaceTexture(texId)
        s.setDefaultBufferSize(srcW, srcH)
        st = s
        s.setOnFrameAvailableListener({ onFrame() }, h)
        val surf = Surface(s)
        srcSurface = surf
        vd = projection.createVirtualDisplay(
            "DZRec", srcW, srcH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surf, null, h
        )
        val listener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                if (displayId == Display.DEFAULT_DISPLAY) onRotate()
            }
        }
        dl = listener
        ctx.getSystemService(DisplayManager::class.java).registerDisplayListener(listener, h)
    }

    private fun onRotate() {
        if (!running) return
        try {
            val s = sourceSize(ctx, side)
            if (s[0] != srcW || s[1] != srcH) {
                srcW = s[0]
                srcH = s[1]
                st?.setDefaultBufferSize(srcW, srcH)
                vd?.resize(srcW, srcH, dpi)
            }
        } catch (e: Exception) {
            // نكمل بالحجم السابق
        }
    }

    // ------------------------------------------------------------ OpenGL
    private fun initGl() {
        val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(d != EGL14.EGL_NO_DISPLAY)
        val ver = IntArray(2)
        check(EGL14.eglInitialize(d, ver, 0, ver, 1))
        eglDisplay = d
        val attr = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE, 1, EGL14.EGL_NONE
        )
        val cfg = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        check(EGL14.eglChooseConfig(d, attr, 0, cfg, 0, 1, num, 0) && num[0] > 0)
        eglCfg = cfg[0]
        eglCtx = EGL14.eglCreateContext(
            d, cfg[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        eglSurf = EGL14.eglCreateWindowSurface(d, cfg[0], inputSurface, intArrayOf(EGL14.EGL_NONE), 0)
        check(EGL14.eglMakeCurrent(d, eglSurf, eglSurf, eglCtx))

        prog = buildProgram()
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aTex = GLES20.glGetAttribLocation(prog, "aTex")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        texId = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        check(ok[0] != 0) { "shader" }
        return s
    }

    private fun buildProgram(): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, VS))
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, FS))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        check(ok[0] != 0) { "link" }
        return p
    }

    private fun onFrame() {
        if (!running) return
        try {
            val s = st ?: return
            s.updateTexImage()
            s.getTransformMatrix(mtx)
            haveFrame = true
            if (paused) return
            val now = System.nanoTime()
            if (now - lastDrawNs < 1_000_000_000L / fps * 9 / 10) return
            drawAndEncode()
        } catch (e: Throwable) {
            fail("توقف التسجيل بسبب خطأ في الترميز")
        }
    }

    /** يكرّر آخر إطار عند ثبات الشاشة ليبقى معدل الإطارات ثابتاً (للبث) */
    private val repeatRun = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                if (haveFrame && !paused &&
                    System.nanoTime() - lastDrawNs > 1_000_000_000L / fps * 12 / 10
                ) drawAndEncode()
            } catch (e: Throwable) {
                fail("توقف البث بسبب خطأ في الترميز")
            }
            handler?.postDelayed(this, 1000L / fps)
        }
    }

    private fun drawAndEncode() {
        val now = System.nanoTime()
        lastDrawNs = now
        val w = cw
        val h = ch
        GLES20.glViewport(0, 0, w, h)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val sw = srcW
        val sh = srcH
        val sc = minOf(w.toFloat() / sw, h.toFloat() / sh)
        val vw = (sw * sc).toInt()
        val vh = (sh * sc).toInt()
        GLES20.glViewport((w - vw) / 2, (h - vh) / 2, vw, vh)

        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glUniformMatrix4fv(uTex, 1, false, mtx, 0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, vbuf)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 0, tbuf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurf, now - startNs - pausedNs)
        EGL14.eglSwapBuffers(eglDisplay, eglSurf)
        drainVideo(false)
    }

    private fun fail(msg: String) {
        if (failed) return
        failed = true
        onError(msg)
    }

    // ------------------------------------------------------------ الفيديو
    private fun drainVideo(eos: Boolean) {
        val enc = venc ?: return
        var tries = 0
        while (true) {
            val i = enc.dequeueOutputBuffer(vinfo, if (eos) 10_000L else 0L)
            if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!eos) return
                tries++
                if (tries > 100) return
            } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                sink.addTrack(true, enc.outputFormat)
            } else if (i >= 0) {
                val b = enc.getOutputBuffer(i)
                if (b != null && vinfo.size > 0 &&
                    (vinfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                ) {
                    sink.write(true, b, vinfo)
                    gotFrame = true
                }
                enc.releaseOutputBuffer(i, false)
                if ((vinfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }

    fun requestKeyFrame() {
        handler?.post {
            try {
                val b = Bundle()
                b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
                venc?.setParameters(b)
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }

    /** تغيير الدقة/الإطارات/معدل البت أثناء البث دون إعادة طلب الإذن */
    fun reconfigure(newSide: Int, w: Int, h: Int, f: Int, br: Int) {
        handler?.post {
            if (!running) return@post
            try {
                EGL14.eglMakeCurrent(
                    eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT
                )
                safe { EGL14.eglDestroySurface(eglDisplay, eglSurf) }
                safe { venc?.stop() }
                safe { venc?.release() }
                safe { inputSurface?.release() }
                side = newSide
                cw = w
                ch = h
                fps = f
                bitrate = br
                sink.resetVideo()
                createVideoEncoder()
                eglSurf = EGL14.eglCreateWindowSurface(
                    eglDisplay, eglCfg, inputSurface, intArrayOf(EGL14.EGL_NONE), 0
                )
                check(EGL14.eglMakeCurrent(eglDisplay, eglSurf, eglSurf, eglCtx))
                onRotate()
                val s = sourceSize(ctx, side)
                if (s[0] != srcW || s[1] != srcH) {
                    srcW = s[0]
                    srcH = s[1]
                    st?.setDefaultBufferSize(srcW, srcH)
                    vd?.resize(srcW, srcH, dpi)
                }
                lastDrawNs = 0L
            } catch (e: Throwable) {
                fail("تعذّر تطبيق الإعداد الجديد")
            }
        }
    }

    // ------------------------------------------------------------ الصوت
    private fun setupAudio() {
        val bufBytes = FRAMES * 4 * 8
        if (audioMode == 1 || audioMode == 3) {
            try {
                val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                val r = AudioRecord.Builder()
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufBytes)
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build()
                if (r.state == AudioRecord.STATE_INITIALIZED) recInt = r else r.release()
            } catch (e: Exception) {
                recInt = null
            }
            if (recInt == null && audioMode == 1) throw IllegalStateException("internal audio")
        }
        if (audioMode == 2 || audioMode == 3) {
            val min = AudioRecord.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min, FRAMES * 2 * 4)
            )
            if (r.state == AudioRecord.STATE_INITIALIZED) recMic = r else {
                r.release()
                if (audioMode == 2) throw IllegalStateException("mic")
            }
        }
        if (recInt == null && recMic == null) return

        val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 2)
        af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        af.setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
        af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        aenc = e
        e.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        e.start()
        needAudio = true
    }

    private fun startAudioThread() {
        audioRun = true
        val t = Thread { audioLoop() }
        audioThread = t
        t.start()
    }

    private fun audioLoop() {
        val sysBuf = ShortArray(FRAMES * 2)
        val micBuf = ShortArray(FRAMES)
        val mix = ShortArray(FRAMES * 2)
        val chunkUs = FRAMES * 1_000_000L / RATE
        var base = 0L
        var total = 0L
        var lastEnd = 0L
        var rebase = true
        try {
            recInt?.startRecording()
            recMic?.startRecording()
            while (audioRun) {
                var okSys = false
                var okMic = false
                val ri = recInt
                if (ri != null) {
                    val n = ri.read(sysBuf, 0, sysBuf.size, AudioRecord.READ_BLOCKING)
                    if (n < 0) break
                    if (n < sysBuf.size) java.util.Arrays.fill(sysBuf, n, sysBuf.size, 0.toShort())
                    okSys = true
                }
                val rm = recMic
                if (rm != null) {
                    val n = rm.read(micBuf, 0, micBuf.size, AudioRecord.READ_BLOCKING)
                    if (n < 0) break
                    if (n < micBuf.size) java.util.Arrays.fill(micBuf, n, micBuf.size, 0.toShort())
                    okMic = true
                }
                if (paused) {
                    rebase = true
                    continue
                }
                for (i in 0 until FRAMES) {
                    var l = 0
                    var r = 0
                    if (okSys) {
                        l += sysBuf[2 * i]
                        r += sysBuf[2 * i + 1]
                    }
                    if (okMic) {
                        l += micBuf[i]
                        r += micBuf[i]
                    }
                    mix[2 * i] = l.coerceIn(-32768, 32767).toShort()
                    mix[2 * i + 1] = r.coerceIn(-32768, 32767).toShort()
                }
                val nowUs = (System.nanoTime() - startNs - pausedNs) / 1000
                if (rebase) {
                    base = maxOf(nowUs - chunkUs, lastEnd, 0L)
                    total = 0
                    rebase = false
                }
                val pts = base + total * 1_000_000L / RATE
                total += FRAMES
                lastEnd = pts + chunkUs
                feedAudio(mix, pts, false)
            }
            feedAudio(null, lastEnd, true)
        } catch (e: Throwable) {
            sink.audioFailed()
        } finally {
            safe { recInt?.stop() }
            safe { recInt?.release() }
            safe { recMic?.stop() }
            safe { recMic?.release() }
            safe { aenc?.stop() }
            safe { aenc?.release() }
            aenc = null
        }
    }

    private fun feedAudio(data: ShortArray?, pts: Long, eos: Boolean) {
        val enc = aenc ?: return
        var tries = if (eos) 50 else 1
        while (tries-- > 0) {
            val idx = enc.dequeueInputBuffer(20_000)
            if (idx >= 0) {
                val b = enc.getInputBuffer(idx)!!
                b.clear()
                b.order(ByteOrder.nativeOrder())
                if (data != null) b.asShortBuffer().put(data, 0, data.size)
                enc.queueInputBuffer(
                    idx, 0, if (data != null) data.size * 2 else 0, pts,
                    if (eos) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0
                )
                break
            }
            drainAudio(false)
        }
        drainAudio(eos)
    }

    private fun drainAudio(eos: Boolean) {
        val enc = aenc ?: return
        var tries = 0
        while (true) {
            val i = enc.dequeueOutputBuffer(ainfo, if (eos) 10_000L else 0L)
            if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!eos) return
                tries++
                if (tries > 100) return
            } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                sink.addTrack(false, enc.outputFormat)
            } else if (i >= 0) {
                val b = enc.getOutputBuffer(i)
                if (b != null && ainfo.size > 0 &&
                    (ainfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                ) sink.write(false, b, ainfo)
                enc.releaseOutputBuffer(i, false)
                if ((ainfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }

    // ------------------------------------------------------------ تحكم
    fun pause() {
        if (!paused) {
            pauseStartNs = System.nanoTime()
            paused = true
        }
    }

    fun resume() {
        if (paused) {
            pausedNs += System.nanoTime() - pauseStartNs
            paused = false
        }
    }

    /** يُنهي كل شيء، ويُرجع true إن كان الناتج صالحاً. */
    fun stop(): Boolean {
        audioRun = false
        safe { audioThread?.join(3000) }

        val h = handler
        if (h != null) {
            val latch = CountDownLatch(1)
            h.post {
                try {
                    finishVideo()
                } catch (e: Throwable) {
                    // تجاهل
                } finally {
                    latch.countDown()
                }
            }
            safe { latch.await(6, TimeUnit.SECONDS) }
        } else {
            safe { venc?.release() }
            safe { inputSurface?.release() }
            safe { recInt?.release() }
            safe { recMic?.release() }
            safe { aenc?.release() }
        }
        safe { thread?.quitSafely() }
        val sinkOk = sink.finish()
        return gotFrame && !failed && sinkOk
    }

    private fun finishVideo() {
        running = false
        handler?.removeCallbacksAndMessages(null)
        safe { dl?.let { ctx.getSystemService(DisplayManager::class.java).unregisterDisplayListener(it) } }
        safe { vd?.release() }
        safe { srcSurface?.release() }
        safe { st?.release() }
        safe { venc?.signalEndOfInputStream() }
        safe { drainVideo(true) }
        safe { venc?.stop() }
        safe { venc?.release() }
        venc = null
        safe { inputSurface?.release() }
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            safe {
                EGL14.eglMakeCurrent(
                    eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT
                )
            }
            safe { EGL14.eglDestroySurface(eglDisplay, eglSurf) }
            safe { EGL14.eglDestroyContext(eglDisplay, eglCtx) }
            safe { EGL14.eglTerminate(eglDisplay) }
        }
    }
}
