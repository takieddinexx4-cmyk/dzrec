package dz.rec

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.ByteArrayOutputStream
import java.io.FileDescriptor
import java.nio.ByteBuffer
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicInteger

/** وجهة العينات المشفّرة: ملف MP4 للتسجيل، أو بث fMP4 مباشر للمتصفحات. */
interface Sink {
    fun setAudio(enabled: Boolean)
    fun addTrack(video: Boolean, fmt: MediaFormat)
    fun write(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo)
    fun audioFailed()
    fun resetVideo() {}
    fun finish(): Boolean
}

// ============================================================ ملف MP4
class Mp4Sink(fd: FileDescriptor) : Sink {
    private class Pending(val video: Boolean, val data: ByteArray, val flags: Int, val pts: Long)

    private val muxer = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val lock = Any()
    private var vTrack = -1
    private var aTrack = -1
    private var started = false
    private var needAudio = false
    private val pending = ArrayList<Pending>()

    override fun setAudio(enabled: Boolean) {
        synchronized(lock) { needAudio = enabled }
    }

    override fun addTrack(video: Boolean, fmt: MediaFormat) {
        synchronized(lock) {
            val idx = muxer.addTrack(fmt)
            if (video) vTrack = idx else aTrack = idx
            tryStart()
        }
    }

    private fun tryStart() {
        if (started || vTrack < 0 || (needAudio && aTrack < 0)) return
        muxer.start()
        started = true
        for (p in pending) {
            val bi = MediaCodec.BufferInfo()
            bi.set(0, p.data.size, p.pts, p.flags)
            muxer.writeSampleData(if (p.video) vTrack else aTrack, ByteBuffer.wrap(p.data), bi)
        }
        pending.clear()
    }

    override fun write(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        synchronized(lock) {
            buf.position(info.offset)
            buf.limit(info.offset + info.size)
            if (started) {
                muxer.writeSampleData(if (video) vTrack else aTrack, buf, info)
            } else {
                val arr = ByteArray(info.size)
                buf.get(arr)
                pending.add(Pending(video, arr, info.flags, info.presentationTimeUs))
            }
        }
    }

    override fun audioFailed() {
        synchronized(lock) {
            needAudio = false
            try {
                tryStart()
            } catch (e: Exception) {
                // سيُكتشف عند الإنهاء
            }
        }
    }

    override fun finish(): Boolean {
        synchronized(lock) {
            var ok = true
            try {
                if (started) muxer.stop() else ok = false
            } catch (e: Exception) {
                ok = false
            }
            try {
                muxer.release()
            } catch (e: Exception) {
                // تجاهل
            }
            return ok
        }
    }
}

// ============================================================ بث fMP4
class FmpSink : Sink {
    class Client {
        val queue = LinkedBlockingQueue<ByteArray>(240)
        @Volatile var synced = false
        @Volatile var pts0 = -1L
        @Volatile var closed = false
    }

    @Volatile var fps = 30
    @Volatile var init: ByteArray? = null
    @Volatile var mime: String? = null
    var requestKey: () -> Unit = {}
    val clients = CopyOnWriteArrayList<Client>()

    private var hasAudio = false
    private var sps: ByteArray? = null
    private var pps: ByteArray? = null
    private var asc: ByteArray? = null
    private var width = 0
    private var height = 0
    private val seq = AtomicInteger(1)

    override fun setAudio(enabled: Boolean) {
        hasAudio = enabled
    }

    override fun addTrack(video: Boolean, fmt: MediaFormat) {
        if (video) {
            val nals = ArrayList<ByteArray>()
            for (k in arrayOf("csd-0", "csd-1")) {
                val bb = fmt.getByteBuffer(k) ?: continue
                val d = ByteArray(bb.remaining())
                bb.duplicate().get(d)
                nals.addAll(Fmp4.splitNals(d))
            }
            for (n in nals) {
                when (n[0].toInt() and 0x1F) {
                    7 -> sps = n
                    8 -> pps = n
                }
            }
            width = fmt.getInteger(MediaFormat.KEY_WIDTH)
            height = fmt.getInteger(MediaFormat.KEY_HEIGHT)
        } else {
            val bb = fmt.getByteBuffer("csd-0")
            if (bb != null) {
                val d = ByteArray(bb.remaining())
                bb.duplicate().get(d)
                asc = d
            }
        }
        build()
    }

    private fun build() {
        val s = sps
        val p = pps
        if (s == null || p == null || s.size < 4) return
        val a = asc
        if (hasAudio && a == null) return
        init = Fmp4.initSegment(s, p, width, height, if (hasAudio) a else null)
        mime = String.format(
            "video/mp4; codecs=\"avc1.%02X%02X%02X%s\"",
            s[1].toInt() and 0xFF, s[2].toInt() and 0xFF, s[3].toInt() and 0xFF,
            if (hasAudio) ",mp4a.40.2" else ""
        )
    }

    override fun audioFailed() {
        hasAudio = false
        build()
    }

    override fun resetVideo() {
        init = null
        mime = null
        sps = null
        pps = null
        for (c in clients) c.closed = true
        clients.clear()
    }

    override fun write(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (clients.isEmpty() || info.size <= 0) return
        val bytes = ByteArray(info.size)
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        buf.get(bytes)
        val key = video && (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
        val payload = if (video) Fmp4.toAvcc(bytes) else bytes
        val pts = info.presentationTimeUs
        val dur = 90000 / fps
        for (c in clients) {
            if (c.closed) continue
            if (video) {
                if (!c.synced) {
                    if (!key) continue
                    c.synced = true
                    if (c.pts0 < 0) c.pts0 = pts
                }
            } else {
                if (!c.synced || pts < c.pts0) continue
            }
            val rel = pts - c.pts0
            val seg = if (video)
                Fmp4.fragment(1, seq.getAndIncrement(), rel * 90000 / 1_000_000L, dur,
                    if (key) 0x02000000 else 0x01010000, payload)
            else
                Fmp4.fragment(2, seq.getAndIncrement(), rel * 44100 / 1_000_000L, 1024,
                    0x02000000, payload)
            if (!c.queue.offer(seg)) {
                // عميل بطيء: نُفرغ المتأخر ونعيد المزامنة من إطار مفتاحي لتبقى المدة قصيرة
                c.queue.clear()
                c.synced = false
                requestKey()
            }
        }
    }

    override fun finish(): Boolean {
        for (c in clients) c.closed = true
        clients.clear()
        return true
    }
}

// ============================================================ صندوق MP4
object Fmp4 {
    private fun i32(v: Int) =
        byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())

    private fun i16(v: Int) = byteArrayOf((v ushr 8).toByte(), v.toByte())
    private fun i64(v: Long) = i32((v ushr 32).toInt()) + i32(v.toInt())
    private fun z(n: Int) = ByteArray(n)
    private fun a4(s: String) = s.toByteArray(Charsets.US_ASCII)

    private fun cat(vararg p: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        for (b in p) o.write(b)
        return o.toByteArray()
    }

    private fun box(type: String, vararg p: ByteArray): ByteArray {
        val body = cat(*p)
        return cat(i32(body.size + 8), a4(type), body)
    }

    private fun full(type: String, version: Int, flags: Int, vararg p: ByteArray): ByteArray =
        box(type, i32((version shl 24) or flags), *p)

    private val matrix = i32(0x10000) + z(12) + i32(0x10000) + z(12) + i32(0x40000000)

    private fun tkhd(id: Int, video: Boolean, w: Int, h: Int) =
        full("tkhd", 0, 7, i32(0), i32(0), i32(id), i32(0), i32(0), z(8), i16(0), i16(0),
            i16(if (video) 0 else 0x0100), i16(0), matrix, i32(w shl 16), i32(h shl 16))

    private fun mdhd(ts: Int) = full("mdhd", 0, 0, i32(0), i32(0), i32(ts), i32(0), i16(0x55C4), i16(0))

    private fun hdlr(type: String, name: String) =
        full("hdlr", 0, 0, i32(0), a4(type), z(12), a4(name), z(1))

    private val dinf = box("dinf", full("dref", 0, 0, i32(1), full("url ", 0, 1)))

    private fun stbl(entry: ByteArray) = box(
        "stbl", full("stsd", 0, 0, i32(1), entry),
        full("stts", 0, 0, i32(0)), full("stsc", 0, 0, i32(0)),
        full("stsz", 0, 0, i32(0), i32(0)), full("stco", 0, 0, i32(0))
    )

    private fun trex(id: Int) = full("trex", 0, 0, i32(id), i32(1), i32(0), i32(0), i32(0))

    fun initSegment(sps: ByteArray, pps: ByteArray, w: Int, h: Int, asc: ByteArray?): ByteArray {
        val ftyp = box("ftyp", a4("isom"), i32(512), a4("isom"), a4("iso5"), a4("iso6"), a4("avc1"), a4("mp41"))
        val mvhd = full("mvhd", 0, 0, i32(0), i32(0), i32(1000), i32(0), i32(0x10000),
            i16(0x0100), z(10), matrix, z(24), i32(3))

        val avcC = box("avcC",
            byteArrayOf(1, sps[1], sps[2], sps[3], 0xFF.toByte(), 0xE1.toByte()),
            i16(sps.size), sps, byteArrayOf(1), i16(pps.size), pps)
        val avc1 = box("avc1", z(6), i16(1), i16(0), i16(0), z(12), i16(w), i16(h),
            i32(0x480000), i32(0x480000), i32(0), i16(1), z(32), i16(0x18), i16(0xFFFF), avcC)
        val trakV = box("trak", tkhd(1, true, w, h),
            box("mdia", mdhd(90000), hdlr("vide", "VideoHandler"),
                box("minf", full("vmhd", 0, 1, z(8)), dinf, stbl(avc1))))

        val traks = ArrayList<ByteArray>()
        traks.add(trakV)
        val trexes = ArrayList<ByteArray>()
        trexes.add(trex(1))

        if (asc != null) {
            val decSpec = byteArrayOf(5, asc.size.toByte()) + asc
            val decConfPayload = byteArrayOf(0x40, 0x15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0) + decSpec
            val decConf = byteArrayOf(4, decConfPayload.size.toByte()) + decConfPayload
            val sl = byteArrayOf(6, 1, 2)
            val esPayload = byteArrayOf(0, 0, 0) + decConf + sl
            val es = byteArrayOf(3, esPayload.size.toByte()) + esPayload
            val esds = full("esds", 0, 0, es)
            val mp4a = box("mp4a", z(6), i16(1), z(8), i16(2), i16(16), i16(0), i16(0),
                i32(44100 shl 16), esds)
            traks.add(
                box("trak", tkhd(2, false, 0, 0),
                    box("mdia", mdhd(44100), hdlr("soun", "SoundHandler"),
                        box("minf", full("smhd", 0, 0, z(4)), dinf, stbl(mp4a))))
            )
            trexes.add(trex(2))
        }
        val moov = box("moov", mvhd, *traks.toTypedArray(), box("mvex", *trexes.toTypedArray()))
        return cat(ftyp, moov)
    }

    fun fragment(trackId: Int, seq: Int, decode: Long, dur: Int, flags: Int, payload: ByteArray): ByteArray {
        fun moof(off: Int) = box(
            "moof", full("mfhd", 0, 0, i32(seq)),
            box("traf", full("tfhd", 0, 0x020000, i32(trackId)),
                full("tfdt", 1, 0, i64(decode)),
                full("trun", 0, 0x000701, i32(1), i32(off), i32(dur), i32(payload.size), i32(flags)))
        )
        val size = moof(0).size
        return cat(moof(size + 8), i32(payload.size + 8), a4("mdat"), payload)
    }

    /** يفصل وحدات NAL من بيانات Annex-B */
    fun splitNals(d: ByteArray): List<ByteArray> {
        val starts = ArrayList<Int>()
        var i = 0
        while (i + 2 < d.size) {
            if (d[i].toInt() == 0 && d[i + 1].toInt() == 0 && d[i + 2].toInt() == 1) {
                starts.add(i + 3)
                i += 3
            } else i++
        }
        val out = ArrayList<ByteArray>()
        for (k in starts.indices) {
            val s = starts[k]
            var e = if (k + 1 < starts.size) starts[k + 1] - 3 else d.size
            if (k + 1 < starts.size && e > s && d[e - 1].toInt() == 0) e--
            if (e > s) out.add(d.copyOfRange(s, e))
        }
        return out
    }

    /** يحوّل Annex-B إلى صيغة بطول 4 بايت لكل وحدة */
    fun toAvcc(d: ByteArray): ByteArray {
        val o = ByteArrayOutputStream(d.size + 16)
        for (n in splitNals(d)) {
            o.write(i32(n.size))
            o.write(n)
        }
        return o.toByteArray()
    }
}
