package dz.rec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

/** بث الشاشة + الصوت كفيديو MP4 حيّ (H.264 + AAC) يُشغَّل في أي متصفح على نفس الشبكة. */
class CastService : Service() {

    companion object {
        const val ACTION_START = "dz.rec.CAST_START"
        const val ACTION_STOP = "dz.rec.CAST_STOP"
        const val ACTION_RECONFIG = "dz.rec.CAST_RECONFIG"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val PORT = 8080
        private const val CHANNEL = "cast"
        private const val NOTIF_ID = 78
    }

    private var projection: MediaProjection? = null
    private var capturer: ScreenCapturer? = null
    private var sink: FmpSink? = null
    private var server: ServerSocket? = null
    private var wifiLock: WifiManager.WifiLock? = null
    @Volatile private var running = false
    @Volatile private var done = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            when (intent?.action) {
                ACTION_START -> start(intent)
                ACTION_STOP -> finish(null)
                ACTION_RECONFIG -> reconfig()
                else -> Log.w("DZRec.Cast", "Unknown service action: ${intent?.action}")
            }
        } catch (t: Throwable) {
            // Never let an initialization exception kill the app process silently.
            Log.e("DZRec.Cast", "Unhandled service startup error", t)
            val detail = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
            CastState.error = "فشل تشغيل خدمة البث: $detail"
            try { finish(CastState.error) } catch (cleanup: Throwable) {
                Log.e("DZRec.Cast", "Cleanup after startup failure failed", cleanup)
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    private fun safe(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            Log.w("DZRec.Cast", "Resource cleanup failed", e)
        }
    }

    private class Params(val side: Int, val w: Int, val h: Int, val fps: Int, val br: Int)

    private fun params(): Params {
        val prefs = Prefs(this)
        val i = prefs.castPreset.coerceIn(0, castNames.size - 1)
        val c = ScreenCapturer.canvasFor(this, castSide[i], prefs.castOrient)
        return Params(castSide[i], c[0], c[1], castFps[i], castMbps[i] * 1_000_000)
    }

    private fun reconfig() {
        val cap = capturer ?: return
        val s = sink ?: return
        val p = params()
        s.fps = p.fps
        cap.reconfigure(p.side, p.w, p.h, p.fps, p.br)
    }

    @Suppress("DEPRECATION")
    private fun start(intent: Intent) {
        if (running) return
        done = false
        val prefs = Prefs(this)
        val ip = CastState.localIp()
        createChannel()

        val hasMicPermission =
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        // Playback capture is a MediaProjection capability and does not require RECORD_AUDIO.
        // Modes 2/3 include microphone input and therefore require the runtime permission.
        val mode = when (prefs.castAudio) {
            1 -> 1
            2 -> if (hasMicPermission) 2 else 0
            3 -> if (hasMicPermission) 3 else 1
            else -> 0
        }
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (Build.VERSION.SDK_INT >= 30 && (mode == 2 || mode == 3)) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        try {
            startForeground(NOTIF_ID, buildNotification(), type)
        } catch (e: Throwable) {
            Log.e("DZRec.Cast", "startForeground failed; sdk=${Build.VERSION.SDK_INT}, mode=$mode", e)
            val detail = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            finish("رفض Android تشغيل خدمة البث: $detail")
            return
        }
        if (ip == null) {
            finish("اتصل بشبكة WiFi أو شغّل الهوتسبوت أولاً")
            return
        }
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) {
            finish("لم يتم منح إذن تسجيل الشاشة")
            return
        }

        try {
            val p = params()
            server = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(PORT))
            }
            val s = FmpSink()
            s.fps = p.fps
            sink = s

            val mpm = getSystemService(MediaProjectionManager::class.java)
            val proj = mpm.getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    finish(null)
                }
            }, Handler(Looper.getMainLooper()))

            val cap = ScreenCapturer(
                this, proj, s, p.w, p.h, p.side, p.fps, p.br, false, mode, true
            ) { msg -> Handler(Looper.getMainLooper()).post { finish(msg) } }
            capturer = cap
            s.requestKey = { cap.requestKeyFrame() }
            cap.start()

            safe {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val l = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "dzrec:cast")
                l.setReferenceCounted(false)
                l.acquire()
                wifiLock = l
            }

            running = true
            CastState.clients.set(0)
            CastState.url = "http://$ip:$PORT"
            CastState.running = true

            val sv = server!!
            Thread {
                while (!sv.isClosed) {
                    try {
                        val c = sv.accept()
                        Thread { handle(c) }.start()
                    } catch (e: Exception) {
                        break
                    }
                }
            }.start()
        } catch (e: Throwable) {
            Log.e("DZRec.Cast", "Cast startup failed; sdk=${Build.VERSION.SDK_INT}", e)
            val detail = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            finish("تعذّر بدء البث: $detail")
        }
    }

    private fun handle(s: Socket) {
        try {
            s.tcpNoDelay = true
            s.sendBufferSize = 128 * 1024
            val inp = s.getInputStream().bufferedReader()
            val line = inp.readLine() ?: return
            while (true) {
                val l = inp.readLine()
                if (l == null || l.isEmpty()) break
            }
            val path = line.split(" ").getOrElse(1) { "/" }
            val out = BufferedOutputStream(s.getOutputStream(), 64 * 1024)
            val sk = sink
            when {
                path.startsWith("/mime") -> {
                    var t = 0
                    while (sk != null && sk.mime == null && running && t < 300) {
                        Thread.sleep(20)
                        t++
                    }
                    val m = sk?.mime
                    if (m == null) {
                        out.write("HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\n\r\n".toByteArray())
                    } else {
                        val body = m.toByteArray()
                        out.write(
                            ("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nCache-Control: no-store\r\n" +
                                "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray()
                        )
                        out.write(body)
                    }
                    out.flush()
                }
                path.startsWith("/live") -> {
                    var t = 0
                    while (sk != null && sk.init == null && running && t < 300) {
                        Thread.sleep(20)
                        t++
                    }
                    val ini = sk?.init
                    if (sk == null || ini == null) {
                        out.write("HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\n\r\n".toByteArray())
                        out.flush()
                        return
                    }
                    out.write(
                        ("HTTP/1.1 200 OK\r\nContent-Type: video/mp4\r\nCache-Control: no-store\r\n" +
                            "Connection: close\r\n\r\n").toByteArray()
                    )
                    out.write(ini)
                    out.flush()
                    val c = FmpSink.Client()
                    sk.clients.add(c)
                    CastState.clients.incrementAndGet()
                    sk.requestKey()
                    try {
                        while (running && !c.closed) {
                            val seg = c.queue.poll(500, TimeUnit.MILLISECONDS)
                            if (seg != null) {
                                out.write(seg)
                                if (c.queue.isEmpty()) out.flush()
                            }
                        }
                    } finally {
                        c.closed = true
                        sk.clients.remove(c)
                        CastState.clients.decrementAndGet()
                    }
                }
                else -> {
                    val body = PAGE.toByteArray()
                    out.write(
                        ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n" +
                            "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray()
                    )
                    out.write(body)
                    out.flush()
                }
            }
        } catch (e: Exception) {
            // العميل أغلق الاتصال
        } finally {
            safe { s.close() }
        }
    }

    private fun finish(error: String?) {
        if (done) return
        done = true
        running = false
        safe { server?.close() }
        server = null
        val cap = capturer
        capturer = null
        safe { cap?.stop() }
        safe { sink?.finish() }
        sink = null
        val p = projection
        projection = null
        safe { p?.stop() }
        safe { wifiLock?.release() }
        wifiLock = null
        CastState.running = false
        CastState.url = null
        if (error != null) CastState.error = error
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (e: Throwable) {
            Log.w("DZRec.Cast", "stopForeground cleanup failed", e)
        }
        stopSelf()
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "البث", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val stopPi = PendingIntent.getService(
            this, 3,
            Intent(this, CastService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 4, Intent(this, CastActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stop), "إيقاف البث", stopPi
        ).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_cast)
            .setContentTitle("DZ Rec — بث الشاشة")
            .setContentText("البث يعمل عبر WiFi")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(action)
            .build()
    }

    override fun onDestroy() {
        finish(null)
        super.onDestroy()
    }
}

private const val PAGE = "<!doctype html><html><head><meta charset=utf-8>" +
    "<meta name=viewport content='width=device-width,initial-scale=1'><title>DZ Rec Cast</title>" +
    "<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}" +
    "video{width:100vw;height:100vh;object-fit:contain;background:#000}" +
    "#h{position:fixed;bottom:14px;left:0;right:0;text-align:center;color:#7fffd4;" +
    "font:15px sans-serif;transition:opacity 1s}</style></head><body>" +
    "<video id=v autoplay muted playsinline></video>" +
    "<div id=h>اضغط على الشاشة لتشغيل الصوت وملء الشاشة</div><script>" +
    "var v=document.getElementById('v'),h=document.getElementById('h'),ms,sb,q,gen=0;" +
    "function retry(g){if(g!==gen)return;gen++;setTimeout(start,1000)}" +
    "function start(){var g=++gen;q=[];sb=null;ms=new MediaSource();v.src=URL.createObjectURL(ms);" +
    "ms.addEventListener('sourceopen',function(){" +
    "fetch('/mime').then(function(r){if(!r.ok)throw 0;return r.text()}).then(function(m){" +
    "sb=ms.addSourceBuffer(m);sb.addEventListener('updateend',pump);return fetch('/live')}).then(function(r){" +
    "var rd=r.body.getReader();(function loop(){rd.read().then(function(x){if(g!==gen)return;" +
    "if(x.done){retry(g);return}q.push(x.value);if(q.length>400)q.splice(0,q.length-200);pump();loop()})" +
    ".catch(function(){retry(g)})})()}).catch(function(){retry(g)})},{once:true})}" +
    "function pump(){if(!sb||sb.updating||!q.length)return;try{sb.appendBuffer(q.shift())}catch(e){}}" +
    "setInterval(function(){if(!sb||!sb.buffered.length)return;" +
    "var e=sb.buffered.end(sb.buffered.length-1),lag=e-v.currentTime;" +
    "if(lag>0.7||(v.readyState<3&&lag>0.05))v.currentTime=e-0.08;" +
    "v.playbackRate=lag>0.35?1.08:1;if(v.paused)v.play().catch(function(){});" +
    "var s=sb.buffered.start(0);if(!sb.updating&&v.currentTime-s>8)try{sb.remove(s,v.currentTime-4)}catch(x){}},250);" +
    "document.body.onclick=function(){v.muted=false;h.style.opacity=0;" +
    "if(document.fullscreenElement)document.exitFullscreen();else document.documentElement.requestFullscreen()};" +
    "start();</script></body></html>"
