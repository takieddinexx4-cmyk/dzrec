package dz.rec

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var timerTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var recBtn: FrameLayout
    private lateinit var recIcon: ImageView
    private lateinit var pauseBtn: TextView
    private lateinit var countTv: TextView
    private lateinit var libTile: View
    private lateinit var castTile: View
    private lateinit var shakeSw: Switch
    private var counting = false
    private var pulsing = false

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        timerTv = findViewById(R.id.timer)
        statusTv = findViewById(R.id.status)
        recBtn = findViewById(R.id.recBtn)
        recIcon = findViewById(R.id.recIcon)
        pauseBtn = findViewById(R.id.pauseBtn)
        countTv = findViewById(R.id.countdown)
        libTile = findViewById(R.id.lastTile)
        castTile = findViewById(R.id.castTile)
        shakeSw = findViewById(R.id.shakeSw)

        recBtn.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onRecordClick()
        }
        pauseBtn.setOnClickListener {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_PAUSE))
        }
        libTile.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            startActivity(Intent(this, LibraryActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        castTile.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            startActivity(Intent(this, CastActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        shakeSw.isChecked = prefs.shake
        shakeSw.setOnCheckedChangeListener { _, c -> prefs.shake = c }
        buildAllChips()
    }

    @Suppress("DEPRECATION")
    private fun buildAllChips() {
        buildChips(this, R.id.rowPreset, Presets.names, -1) { i ->
            prefs.shortSide = Presets.side[i]
            prefs.fps = Presets.fps[i]
            prefs.bitrate = Presets.recMbps[i]
            prefs.format = 0
            buildAllChips()
        }

        val resVals = listOf(720, 1080, 1440, 0)
        buildChips(this, R.id.rowRes, listOf("720p", "1080p", "2K", "أصلية"),
            resVals.indexOf(prefs.shortSide).coerceAtLeast(0)) { prefs.shortSide = resVals[it] }

        val hz = windowManager.defaultDisplay.supportedModes.maxOf { it.refreshRate }.toInt()
        val fpsVals = listOf(24, 30, 60, 90, 120).filter { it <= maxOf(hz, 30) }
        if (prefs.fps !in fpsVals) prefs.fps = 30
        buildChips(this, R.id.rowFps, fpsVals.map { "$it fps" }, fpsVals.indexOf(prefs.fps)) {
            prefs.fps = fpsVals[it]
        }

        val brVals = listOf(0, 6, 12, 20, 32, 50)
        buildChips(this, R.id.rowBr, listOf("تلقائي", "6", "12", "20", "32", "50"),
            brVals.indexOf(prefs.bitrate).coerceAtLeast(0)) { prefs.bitrate = brVals[it] }

        buildChips(this, R.id.rowFmt, listOf("MP4 · H.264", "MP4 · HEVC"),
            prefs.format.coerceIn(0, 1)) { prefs.format = it }

        buildChips(this, R.id.rowAudio, listOf("بدون", "صوت النظام", "ميكروفون", "الاثنان"),
            prefs.audioMode.coerceIn(0, 3)) { prefs.audioMode = it }

        buildChips(this, R.id.rowOri, listOf("تلقائي", "عمودي", "أفقي"),
            prefs.orient.coerceIn(0, 2)) { prefs.orient = it }

        val cdVals = listOf(0, 3, 5, 10)
        buildChips(this, R.id.rowCd, listOf("بدون", "3 ث", "5 ث", "10 ث"),
            cdVals.indexOf(prefs.countdown).coerceAtLeast(0)) { prefs.countdown = cdVals[it] }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun setPulse(on: Boolean) {
        if (on == pulsing) return
        pulsing = on
        if (on) {
            val a = ScaleAnimation(
                1f, 1.1f, 1f, 1.1f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f
            )
            a.duration = 700
            a.repeatMode = Animation.REVERSE
            a.repeatCount = Animation.INFINITE
            recBtn.startAnimation(a)
        } else {
            recBtn.clearAnimation()
        }
    }

    private fun refresh() {
        RecState.error?.let {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            RecState.error = null
        }
        if (RecState.recording) {
            val s = RecState.elapsedMs() / 1000
            timerTv.text = if (s >= 3600)
                String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
            else String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
            statusTv.text = if (RecState.paused) "متوقف مؤقتاً" else "جارٍ التسجيل…"
            recIcon.setImageResource(R.drawable.ic_stop)
            pauseBtn.visibility = View.VISIBLE
            pauseBtn.text = if (RecState.paused) "استئناف" else "إيقاف مؤقت"
            setPulse(!RecState.paused)
        } else {
            if (!counting) {
                timerTv.text = "00:00"
                statusTv.text = "جاهز للتسجيل"
            }
            recIcon.setImageResource(R.drawable.ic_rec)
            pauseBtn.visibility = View.GONE
            setPulse(false)
        }
    }

    private fun onRecordClick() {
        if (RecState.recording) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            return
        }
        if (counting) return
        val need = mutableListOf<String>()
        if (prefs.audioMode in 2..3 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 10) else askCapture()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            val micNeeded = prefs.audioMode in 2..3
            val micGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (micNeeded && !micGranted) {
                Toast.makeText(this, "لم يُمنح إذن الميكروفون؛ سيستمر التسجيل دون صوت الميكروفون", Toast.LENGTH_LONG).show()
            }
            askCapture()
        }
    }

    @Suppress("DEPRECATION")
    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 20)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20) {
            if (resultCode == RESULT_OK && data != null) countdown(resultCode, data)
            else Toast.makeText(this, "تم إلغاء التسجيل", Toast.LENGTH_SHORT).show()
        }
    }

    private fun countdown(code: Int, data: Intent) {
        if (prefs.countdown <= 0) {
            begin(code, data)
            return
        }
        counting = true
        countTv.visibility = View.VISIBLE
        var n = prefs.countdown
        val step = object : Runnable {
            override fun run() {
                if (n > 0) {
                    countTv.text = n.toString()
                    countTv.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    n--
                    ui.postDelayed(this, 1000)
                } else {
                    countTv.visibility = View.GONE
                    counting = false
                    begin(code, data)
                }
            }
        }
        ui.post(step)
    }

    private fun begin(code: Int, data: Intent) {
        val i = Intent(this, RecorderService::class.java)
            .setAction(RecorderService.ACTION_START)
            .putExtra(RecorderService.EXTRA_CODE, code)
            .putExtra(RecorderService.EXTRA_DATA, data)
        startForegroundService(i)
        ui.postDelayed({ moveTaskToBack(true) }, 500)
    }
}
