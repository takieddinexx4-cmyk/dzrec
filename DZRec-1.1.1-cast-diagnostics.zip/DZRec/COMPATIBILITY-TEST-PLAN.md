# DZ Rec 1.1.0 — Android compatibility test plan

## Declared support range
- Minimum supported OS: Android 10 (API 29).
- Compile SDK / target SDK: API 35.
- Newer Android releases are expected to run the app through platform compatibility, but must be verified on devices before a release claim is made.

## Required device matrix
| OS | API | Required checks |
|---|---:|---|
| Android 10 | 29 | Start/stop screen recording; local cast; microphone; orientation change |
| Android 11 | 30 | Foreground-service microphone type; background/notification behavior |
| Android 12/12L | 31/32 | Foreground-service start restrictions; screen capture consent |
| Android 13 | 33 | Notification permission granted and denied |
| Android 14 | 34 | MediaProjection foreground-service permission; one consent token per session |
| Android 15 | 35 | Target-35 behavior; edge-to-edge layout; foreground service behavior |
| Android 16/17 | 36/37 if applicable | Regression tests on actual OS builds and OEM devices |

## Functional checks
1. Start and stop recording repeatedly; verify the MP4 is playable and appears in Movies/DZRec.
2. Test audio modes independently: none, system audio, microphone, both. Denying microphone permission must not disable system playback capture.
3. Start cast, open its URL from another device on the same Wi-Fi, keep it running for at least 10 minutes, and verify reconnect behavior after Wi-Fi interruption.
4. Switch portrait/landscape and change each quality preset while casting.
5. Lock/unlock the phone, switch apps, receive a call, and stop from the persistent notification.
6. Repeat tests with low memory, weak Wi-Fi, and battery saver enabled.

## Validation status for this source package
- Android XML files parse successfully.
- Manifest permission declarations and SDK configuration were checked.
- Kotlin parser check found no syntax diagnostics; a full Kotlin/Android compile was not possible in this environment because Android SDK/Gradle are not installed.
- No physical-device or end-to-end casting test has been run. Do not label this package production-certified until the matrix above passes.
