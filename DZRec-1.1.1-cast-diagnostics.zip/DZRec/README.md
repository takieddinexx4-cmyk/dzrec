# DZ Rec — المرحلة 1 (مسجّل الشاشة)

## بناء APK مجاناً (بدون حاسوب قوي)
1. أنشئ حساب GitHub مجاني ومستودعاً جديداً (Private أو Public).
2. ارفع محتوى هذا المجلد كما هو (بما فيه مجلد `.github`).
3. تبويب **Actions** ← **Build APK** ← انتظر ~5 دقائق.
4. حمّل `DZRec-apk` من أسفل صفحة التشغيل، فك الضغط، ثبّت `app-debug.apk`.

بديل: افتح المجلد في Android Studio (مجاني) ثم Run.

## ملاحظات
- الحد الأدنى: Android 10 (API 29)، مع استهداف Android 15 (API 35) للتوافق السلوكي الحديث. يعمل التطبيق على الإصدارات الأحدث، ومنها Android 17، مع ضرورة الاختبار على الأجهزة الفعلية.
- يُحفظ الفيديو في `Movies/DZRec`.
- خيارات FPS تُعرض حسب أقصى معدل تحديث لشاشة هاتفك.


## تحسينات هذه النسخة
- إصلاح تعريف نوع خدمة البث الأمامية ليشمل `microphone` عند تشغيل خيارات الصوت، بما يتوافق مع متطلبات Android الحديثة.
- إيقاف بدء البث الصوتي بصمت عند رفض إذن الميكروفون، مع توضيح الإجراء للمستخدم.
- إضافة خمس درجات بث واضحة من 720p/30 إلى الدقة الأصلية/60 مع معدلات نقل بيانات مختلفة.
- إضافة استجابة لمسية وحركة ضغط خفيفة للأزرار وخيارات الجودة، وانتقالات تلاشي بين الشاشات.
- تسجيل سبب فشل بدء البث في سجل النظام وإظهار تفاصيل الخطأ بدلاً من رسالة عامة فقط.

ملاحظة: يجب اختبار البث على الهاتف الفعلي والشاشة المستقبلة؛ دعم 1440p والدقة الأصلية و60 إطاراً يعتمد على قدرات مشفّر الجهاز وقوة شبكة Wi-Fi.


## توافق Android والتحسينات التقنية (1.1.0)
- تم رفع compileSdk/targetSdk إلى API 35 وتحديث Android Gradle Plugin إلى 8.7.3.
- بقي الحد الأدنى API 29 لأن التقاط صوت تشغيل التطبيقات يتطلب Android 10 أو أحدث.
- فصل صلاحية التقاط صوت النظام عن صلاحية الميكروفون؛ رفض إذن الميكروفون لا يعطّل التقاط صوت النظام.
- منع اعتبار إيقاف AudioRecord المقصود خطأً دائماً في مسار الصوت، وإيقاف القراءة الحاجبة قبل انتظار خيط الصوت.
- يجب التحقق من البناء عبر Gradle ومن اختبار التسجيل والبث على Android 10 و13 و14 و15 و17 وأجهزة مختلفة؛ لم يُجرَ اختبار جهاز فعلي ضمن هذه الحزمة.


## Cast startup diagnostics (1.1.1)

The cast Activity now catches failures while launching the foreground service and keeps the cast screen open. The service logs the full startup exception under the `DZRec.Cast` tag and reports the platform error text in the cast screen instead of silently returning to the launcher.

If startup still fails, capture Android Studio Logcat with filter `DZRec.Cast` immediately after pressing Start Cast. Include the first `SecurityException`, `ForegroundServiceStartNotAllowedException`, `MissingForegroundServiceTypeException`, or `IllegalStateException` stack trace. This is required to distinguish OEM restrictions from a codec/MediaProjection failure.
