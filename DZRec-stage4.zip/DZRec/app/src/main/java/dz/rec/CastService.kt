package dz.rec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/** يبث الشاشة كفيديو MJPEG عبر HTTP؛ يُفتح الرابط في أي متصفح على نفس الشبكة. */
class CastService : Service() {

    companion object {
        const val ACTION_START = "dz.rec.CAST_START"
        const val ACTION_STOP = "dz.rec.CAST_STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val PORT = 8080
        private const val CHANNEL = "cast"
        private const val NOTIF_ID = 78
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var server: ServerSocket? = null
    private var bmp: Bitmap? = null

    @Volatile private var frame: ByteArray? = null
    @Volatile private var frameId = 0L
    @Volatile private var running = false
    @Volatile private var done = false
    private var lastMs = 0L
    private var pending = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> finish(null)
        }
        return START_NOT_STICKY
    }

    private fun safe(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            // تجاهل
        }
    }

    @Suppress("DEPRECATION")
    private fun start(intent: Intent) {
        if (running) return
        done = false
        val prefs = Prefs(this)
        val ip = CastState.localIp()
        createChannel()
        try {
            startForeground(
                NOTIF_ID, buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } catch (e: Exception) {
            finish("تعذّر تشغيل خدمة البث")
            return
        }
        if (ip == null) {
            finish("اتصل بشبكة WiFi أو شغّل الهوتسبوت أولاً")
            return
        }
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) {
            finish("لم يتم منح إذن تسجيل الشاشة")
            return
        }

        try {
            val dm = DisplayMetrics()
            getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(dm)
            var w = dm.widthPixels
            var h = dm.heightPixels
            val ss = prefs.castSide
            val short = minOf(w, h)
            if (ss > 0 && short > ss) {
                val r = ss.toFloat() / short
                w = (w * r).toInt()
                h = (h * r).toInt()
            }
            w = w and 1.inv()
            h = h and 1.inv()
            val q = prefs.castQ
            val minInterval = 1000L / prefs.castFps

            // المنفذ أولاً حتى نعرف إن كان مشغولاً
            server = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(PORT))
            }

            val t = HandlerThread("dzcast")
            t.start()
            thread = t
            val hd = Handler(t.looper)
            handler = hd

            val rd = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
            reader = rd
            rd.setOnImageAvailableListener({ onFrame(it, w, h, q, minInterval) }, hd)

            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    finish(null)
                }
            }, Handler(Looper.getMainLooper()))
            vd = p.createVirtualDisplay(
                "DZCast", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                rd.surface, null, hd
            )

            running = true
            CastState.clients.set(0)
            CastState.url = "http://$ip:$PORT"
            CastState.running = true

            val sv = server!!
            Thread {
                while (!sv.isClosed) {
                    try {
                        val c = sv.accept()
                        Thread { handle(c) }.start()
                    } catch (e: Exception) {
                        break
                    }
                }
            }.start()
        } catch (e: Exception) {
            finish("تعذّر بدء البث (قد يكون المنفذ $PORT مشغولاً)")
        }
    }

    private fun onFrame(r: ImageReader, w: Int, h: Int, q: Int, minInterval: Long) {
        if (!running) return
        val now = SystemClock.elapsedRealtime()
        val wait = minInterval - (now - lastMs)
        if (wait > 0) {
            // نؤجّل بدل الإسقاط حتى لا يبقى آخر تغيير غير مرسل
            if (!pending) {
                pending = true
                handler?.postDelayed({
                    pending = false
                    onFrame(r, w, h, q, minInterval)
                }, wait)
            }
            return
        }
        var got: android.media.Image? = null
        try {
            got = r.acquireLatestImage()
        } catch (e: Exception) {
            got = null
        }
        val img = got
        if (img == null) return
        try {
            lastMs = now
            val plane = img.planes[0]
            val bw = plane.rowStride / plane.pixelStride
            var b = bmp
            if (b == null || b.width != bw || b.height != h) {
                b = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888)
                bmp = b
            }
            plane.buffer.rewind()
            b!!.copyPixelsFromBuffer(plane.buffer)
            val src = if (bw != w) Bitmap.createBitmap(b, 0, 0, w, h) else b
            val out = ByteArrayOutputStream(256 * 1024)
            src.compress(Bitmap.CompressFormat.JPEG, q, out)
            if (src !== b) src.recycle()
            frame = out.toByteArray()
            frameId++
        } catch (e: Exception) {
            // نتجاوز هذا الإطار
        } finally {
            img.close()
        }
    }

    private fun handle(s: Socket) {
        try {
            s.tcpNoDelay = true
            val inp = s.getInputStream().bufferedReader()
            val line = inp.readLine() ?: return
            while (true) {
                val l = inp.readLine()
                if (l == null || l.isEmpty()) break
            }
            val path = line.split(" ").getOrElse(1) { "/" }
            val out = BufferedOutputStream(s.getOutputStream())
            if (path.startsWith("/stream")) {
                out.write(
                    ("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                        "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray()
                )
                CastState.clients.incrementAndGet()
                try {
                    var last = -1L
                    while (running) {
                        val id = frameId
                        val f = frame
                        if (f != null && id != last) {
                            last = id
                            out.write(
                                ("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${f.size}\r\n\r\n")
                                    .toByteArray()
                            )
                            out.write(f)
                            out.write("\r\n".toByteArray())
                            out.flush()
                        } else {
                            Thread.sleep(4)
                        }
                    }
                } finally {
                    CastState.clients.decrementAndGet()
                }
            } else {
                val body = PAGE.toByteArray()
                out.write(
                    ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n" +
                        "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray()
                )
                out.write(body)
                out.flush()
            }
        } catch (e: Exception) {
            // العميل أغلق الاتصال
        } finally {
            safe { s.close() }
        }
    }

    private fun finish(error: String?) {
        if (done) return
        done = true
        running = false
        safe { server?.close() }
        server = null
        safe { vd?.release() }
        vd = null
        safe { reader?.close() }
        reader = null
        val p = projection
        projection = null
        safe { p?.stop() }
        safe { thread?.quitSafely() }
        thread = null
        safe { bmp?.recycle() }
        bmp = null
        CastState.running = false
        CastState.url = null
        if (error != null) CastState.error = error
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "البث", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val stopPi = PendingIntent.getService(
            this, 3,
            Intent(this, CastService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 4, Intent(this, CastActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stop), "إيقاف البث", stopPi
        ).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_cast)
            .setContentTitle("DZ Rec — بث الشاشة")
            .setContentText("البث يعمل عبر WiFi")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(action)
            .build()
    }

    override fun onDestroy() {
        finish(null)
        super.onDestroy()
    }
}

private const val PAGE = "<!doctype html><html><head><meta charset=utf-8>" +
    "<meta name=viewport content='width=device-width,initial-scale=1'><title>DZ Rec Cast</title>" +
    "<style>html,body{margin:0;height:100%;background:#000}" +
    "img{width:100vw;height:100vh;object-fit:contain;display:block}</style></head><body>" +
    "<img id=i src=/stream><script>var i=document.getElementById('i');" +
    "i.onerror=function(){setTimeout(function(){i.src='/stream?'+Date.now()},1000)};" +
    "document.body.onclick=function(){if(document.fullscreenElement){document.exitFullscreen()}" +
    "else{document.documentElement.requestFullscreen()}}</script></body></html>"
