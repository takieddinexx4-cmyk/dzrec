package dz.rec

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class CastActivity : Activity() {

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var statusTv: TextView
    private lateinit var urlTv: TextView
    private lateinit var startBtn: TextView
    private lateinit var copyBtn: TextView

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cast)
        prefs = Prefs(this)

        statusTv = findViewById(R.id.castStatus)
        urlTv = findViewById(R.id.castUrl)
        startBtn = findViewById(R.id.startBtn)
        copyBtn = findViewById(R.id.copyBtn)
        startBtn.isSelected = true
        findViewById<TextView>(R.id.backBtn).setOnClickListener { finish() }

        val resVals = listOf(480, 720, 1080, 0)
        buildChips(this, R.id.rowRes, listOf("480p", "720p", "1080p", "أصلية"),
            resVals.indexOf(prefs.castSide).coerceAtLeast(0)) { prefs.castSide = resVals[it] }

        val fpsVals = listOf(15, 24, 30, 60)
        buildChips(this, R.id.rowFps, fpsVals.map { "$it fps" },
            fpsVals.indexOf(prefs.castFps).coerceAtLeast(0)) { prefs.castFps = fpsVals[it] }

        val qVals = listOf(60, 80, 95)
        buildChips(this, R.id.rowQ, listOf("متوسطة", "عالية", "أصلية"),
            qVals.indexOf(prefs.castQ).coerceAtLeast(0)) { prefs.castQ = qVals[it] }

        startBtn.setOnClickListener { onStartClick() }
        copyBtn.setOnClickListener {
            val u = CastState.url
            if (u == null) {
                Toast.makeText(this, "ابدأ البث أولاً", Toast.LENGTH_SHORT).show()
            } else {
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("url", u))
                Toast.makeText(this, "تم نسخ الرابط", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun refresh() {
        CastState.error?.let {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            CastState.error = null
        }
        if (CastState.running) {
            statusTv.text = "البث يعمل · المتصلون: ${CastState.clients.get()}"
            urlTv.text = CastState.url ?: ""
            startBtn.text = "إيقاف البث"
        } else {
            statusTv.text = "البث متوقف"
            urlTv.text = "سيظهر الرابط هنا"
            startBtn.text = "بدء البث"
        }
    }

    private fun onStartClick() {
        if (CastState.running) {
            startService(Intent(this, CastService::class.java).setAction(CastService.ACTION_STOP))
            return
        }
        if (CastState.localIp() == null) {
            Toast.makeText(this, "اتصل بشبكة WiFi أو شغّل الهوتسبوت أولاً", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        } else askCapture()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11) askCapture()
    }

    @Suppress("DEPRECATION")
    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 21)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 21) {
            if (resultCode == RESULT_OK && data != null) {
                startForegroundService(
                    Intent(this, CastService::class.java)
                        .setAction(CastService.ACTION_START)
                        .putExtra(CastService.EXTRA_CODE, resultCode)
                        .putExtra(CastService.EXTRA_DATA, data)
                )
            } else {
                Toast.makeText(this, "تم إلغاء البث", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

fun buildChips(a: Activity, rowId: Int, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    val row = a.findViewById<LinearLayout>(rowId)
    val d = a.resources.displayMetrics.density
    fun dp(v: Int) = (v * d).toInt()
    row.removeAllViews()
    labels.forEachIndexed { i, label ->
        val t = TextView(a)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.textSize = 14f
        t.setPadding(dp(16), dp(10), dp(16), dp(10))
        t.setBackgroundResource(R.drawable.bg_chip)
        t.isSelected = i == selected
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.marginEnd = dp(8)
        t.layoutParams = lp
        t.setOnClickListener {
            for (k in 0 until row.childCount) row.getChildAt(k).isSelected = k == i
            onPick(i)
        }
        row.addView(t)
    }
}
