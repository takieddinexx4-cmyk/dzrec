package dz.rec

import android.content.Context
import android.net.Uri

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("dzrec", Context.MODE_PRIVATE)

    /** الضلع الأقصر بالبكسل: 720 / 1080 / 1440 / 0 = أصلية */
    var shortSide: Int
        get() = sp.getInt("ss", 1080)
        set(v) = sp.edit().putInt("ss", v).apply()

    var fps: Int
        get() = sp.getInt("fps", 30)
        set(v) = sp.edit().putInt("fps", v).apply()

    /** Mbps — 0 = تلقائي */
    var bitrate: Int
        get() = sp.getInt("br", 0)
        set(v) = sp.edit().putInt("br", v).apply()

    /** 0 = MP4 H.264 ، 1 = MP4 HEVC ، 2 = WebM */
    var format: Int
        get() = sp.getInt("fmt", 0)
        set(v) = sp.edit().putInt("fmt", v).apply()

    var audio: Boolean
        get() = sp.getBoolean("audio", false)
        set(v) = sp.edit().putBoolean("audio", v).apply()

    var castSide: Int
        get() = sp.getInt("cside", 720)
        set(v) = sp.edit().putInt("cside", v).apply()

    var castFps: Int
        get() = sp.getInt("cfps", 30)
        set(v) = sp.edit().putInt("cfps", v).apply()

    /** جودة JPEG للبث */
    var castQ: Int
        get() = sp.getInt("cq", 80)
        set(v) = sp.edit().putInt("cq", v).apply()

    /** ثواني العدّ التنازلي: 0 / 3 / 5 / 10 */
    var countdown: Int
        get() = sp.getInt("cd", 3)
        set(v) = sp.edit().putInt("cd", v).apply()

    /** هزّ الهاتف 3 مرات لإيقاف التسجيل */
    var shake: Boolean
        get() = sp.getBoolean("shake", false)
        set(v) = sp.edit().putBoolean("shake", v).apply()

    /** 0 بدون، 1 صوت النظام، 2 ميكروفون، 3 الاثنان */
    var audioMode: Int
        get() = sp.getInt("am", if (sp.getBoolean("audio", false)) 2 else 0)
        set(v) = sp.edit().putInt("am", v).apply()

    /** اتجاه الفيديو: 0 تلقائي، 1 عمودي، 2 أفقي */
    var orient: Int
        get() = sp.getInt("ori", 0)
        set(v) = sp.edit().putInt("ori", v).apply()

    var lastUri: String?
        get() = sp.getString("last", null)
        set(v) = sp.edit().putString("last", v).apply()
}

object RecState {
    @Volatile var recording = false
    @Volatile var paused = false
    @Volatile var accumMs = 0L
    @Volatile var activeSince = 0L

    /** مدة التسجيل الفعلية دون احتساب فترات الإيقاف المؤقت */
    fun elapsedMs(): Long =
        accumMs + if (paused) 0L else (android.os.SystemClock.elapsedRealtime() - activeSince)
    @Volatile var lastUri: Uri? = null
    @Volatile var error: String? = null
}
