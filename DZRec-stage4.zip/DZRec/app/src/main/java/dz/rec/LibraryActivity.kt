package dz.rec

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class LibraryActivity : Activity() {

    private class Item(
        val id: Long, val uri: Uri, val name: String,
        val durMs: Long, val size: Long, val dateSec: Long
    )

    private val items = ArrayList<Item>()
    private val cache = LruCache<Long, Bitmap>(60)
    private val pool = Executors.newFixedThreadPool(2)
    private lateinit var list: ListView
    private lateinit var emptyTv: TextView

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = items[p].id

        override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: LayoutInflater.from(this@LibraryActivity)
                .inflate(R.layout.item_video, parent, false)
            val it = items[p]
            val iv = v.findViewById<ImageView>(R.id.thumb)
            v.findViewById<TextView>(R.id.vName).text = it.name
            val sec = it.durMs / 1000
            v.findViewById<TextView>(R.id.vMeta).text = String.format(
                Locale.US, "%02d:%02d · %.1f MB · %s", sec / 60, sec % 60,
                it.size / 1048576.0,
                SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(it.dateSec * 1000))
            )
            iv.tag = it.id
            val cached = cache.get(it.id)
            if (cached != null) {
                iv.setImageBitmap(cached)
            } else {
                iv.setImageResource(R.drawable.ic_play)
                pool.execute {
                    try {
                        val b = contentResolver.loadThumbnail(it.uri, Size(240, 160), null)
                        cache.put(it.id, b)
                        runOnUiThread { if (iv.tag == it.id) iv.setImageBitmap(b) }
                    } catch (e: Exception) {
                        // نترك الأيقونة الافتراضية
                    }
                }
            }
            return v
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)
        list = findViewById(R.id.list)
        emptyTv = findViewById(R.id.empty)
        findViewById<TextView>(R.id.backBtn).setOnClickListener { finish() }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> showMenu(items[pos]) }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun load() {
        Thread {
            val out = ArrayList<Item>()
            try {
                val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val proj = arrayOf(
                    MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE,
                    MediaStore.Video.Media.DATE_ADDED
                )
                contentResolver.query(
                    base, proj,
                    MediaStore.Video.Media.RELATIVE_PATH + " LIKE ?", arrayOf("Movies/DZRec%"),
                    MediaStore.Video.Media.DATE_ADDED + " DESC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        out.add(
                            Item(id, ContentUris.withAppendedId(base, id), c.getString(1) ?: "",
                                c.getLong(2), c.getLong(3), c.getLong(4))
                        )
                    }
                }
            } catch (e: Exception) {
                // قائمة فارغة
            }
            runOnUiThread {
                items.clear()
                items.addAll(out)
                adapter.notifyDataSetChanged()
                emptyTv.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun showMenu(it: Item) {
        AlertDialog.Builder(this)
            .setTitle(it.name)
            .setItems(arrayOf("تشغيل", "مشاركة", "حذف")) { _, which ->
                when (which) {
                    0 -> play(it)
                    1 -> share(it)
                    2 -> confirmDelete(it)
                }
            }.show()
    }

    private fun mime(u: Uri) = contentResolver.getType(u) ?: "video/*"

    private fun play(it: Item) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(it.uri, mime(it.uri))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "لا يوجد مشغّل فيديو", Toast.LENGTH_SHORT).show()
        }
    }

    private fun share(it: Item) {
        val i = Intent(Intent.ACTION_SEND).setType(mime(it.uri))
            .putExtra(Intent.EXTRA_STREAM, it.uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "مشاركة التسجيل"))
    }

    private fun confirmDelete(it: Item) {
        AlertDialog.Builder(this)
            .setMessage("حذف هذا التسجيل نهائياً؟")
            .setPositiveButton("حذف") { _, _ ->
                try {
                    contentResolver.delete(it.uri, null, null)
                    val p = Prefs(this)
                    if (p.lastUri == it.uri.toString()) p.lastUri = null
                    if (RecState.lastUri == it.uri) RecState.lastUri = null
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذّر الحذف", Toast.LENGTH_SHORT).show()
                }
                load()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
