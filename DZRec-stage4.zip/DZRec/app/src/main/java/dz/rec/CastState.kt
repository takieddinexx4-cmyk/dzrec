package dz.rec

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger

object CastState {
    @Volatile var running = false
    @Volatile var url: String? = null
    @Volatile var error: String? = null
    val clients = AtomicInteger(0)

    /** عنوان الهاتف في الشبكة المحلية (WiFi أو الهوتسبوت) */
    fun localIp(): String? {
        try {
            var fallback: String? = null
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && a.isSiteLocalAddress) {
                        if (ni.name.startsWith("wlan")) return a.hostAddress
                        if (fallback == null) fallback = a.hostAddress
                    }
                }
            }
            return fallback
        } catch (e: Exception) {
            return null
        }
    }
}
